import React from "react";
import PeopleNav from "../navbars/Navbars/PeopleNav";
import Attendance from "./Attendance/Attendance";
const People = () => {
  return (
    <div>
      <PeopleNav />
    </div>
  );
};
export default People;
